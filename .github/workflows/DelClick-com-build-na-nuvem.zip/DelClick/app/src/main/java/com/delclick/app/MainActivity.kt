package com.delclick.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0D0B13)
private val Panel = Color(0xFF15111D)
private val Panel2 = Color(0xFF211A30)
private val Purple = Color(0xFF7952E8)
private val PurpleLight = Color(0xFFB69CFF)
private val Muted = Color(0xFF9991A8)
private val Green = Color(0xFF62D594)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DelClickApp() }
    }
}

@Composable
fun DelClickApp() {
    var page by remember { mutableStateOf("Início") }
    var drawer by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf("Mouse e teclado") }
    var shiftLock by remember { mutableStateOf(true) }
    var cameraToggle by remember { mutableStateOf(false) }
    var cursorAlways by remember { mutableStateOf(false) }
    var autoclick by remember { mutableStateOf(false) }
    var clickRate by remember { mutableFloatStateOf(12f) }
    var sensitivity by remember { mutableFloatStateOf(1f) }
    var macroCount by remember { mutableIntStateOf(1) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Panel, primary = Purple,
            secondary = PurpleLight, onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Box(Modifier.fillMaxSize().background(Bg)) {
            Column(Modifier.fillMaxSize()) {
                Header(onMenu = { drawer = true }, page = page)
                when (page) {
                    "Início" -> HomeScreen(
                        mode = mode, onMode = { mode = it },
                        onSettings = { page = "Sensibilidade" },
                        onPlay = { page = "Painel" }
                    )
                    "Sensibilidade" -> SettingsScreen(
                        sensitivity, { sensitivity = it },
                        shiftLock, { shiftLock = it },
                        cameraToggle, { cameraToggle = it },
                        cursorAlways, { cursorAlways = it }
                    )
                    "Macros" -> MacroScreen(macroCount, { macroCount = it })
                    "Autoclick" -> AutoClickScreen(autoclick, { autoclick = it }, clickRate, { clickRate = it })
                    "Teclado" -> KeyboardScreen()
                    "Painel" -> GamePanel(
                        autoclick, { autoclick = it }, clickRate, { clickRate = it },
                        shiftLock, { shiftLock = it }
                    )
                    else -> HomeScreen(mode, { mode = it }, { page = "Sensibilidade" }, { page = "Painel" })
                }
            }
            if (drawer) {
                Row(Modifier.fillMaxSize()) {
                    Column(
                        Modifier.fillMaxHeight().width(300.dp).background(Panel).padding(20.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(color = Purple, shape = RoundedCornerShape(16.dp)) {
                                Icon(Icons.Default.Mouse, null, Modifier.padding(15.dp), tint = Color.White)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text("DECLICK", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                Text("Configurações", color = Muted, fontSize = 13.sp)
                            }
                            Spacer(Modifier.weight(1f))
                            IconButton(onClick = { drawer = false }) { Icon(Icons.Default.Close, null) }
                        }
                        Divider(Modifier.padding(vertical = 18.dp), color = Panel2)
                        Text("MOUSE E TECLADO", color = Muted, fontSize = 12.sp)
                        listOf("Sensibilidade", "Teclado", "Macros", "Autoclick", "Painel").forEach {
                            DrawerItem(it, page == it) { page = it; drawer = false }
                        }
                        Spacer(Modifier.weight(1f))
                        Text("DelClick 1.0-alpha", color = Muted, fontSize = 12.sp)
                    }
                    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .55f)).clickable { drawer = false })
                }
            }
        }
    }
}

@Composable
fun Header(onMenu: () -> Unit, page: String) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        OutlinedButton(onClick = onMenu, shape = RoundedCornerShape(18.dp)) {
            Icon(Icons.Default.Menu, null, tint = PurpleLight)
        }
        Spacer(Modifier.width(10.dp))
        Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.weight(1f)) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(9.dp).background(Green, RoundedCornerShape(50)))
                Spacer(Modifier.width(10.dp))
                Text(page, fontWeight = FontWeight.Medium)
            }
        }
        Spacer(Modifier.width(8.dp))
        OutlinedButton(onClick = {}, shape = RoundedCornerShape(18.dp)) {
            Icon(Icons.Default.Download, null, tint = PurpleLight)
        }
    }
}

@Composable
fun HomeScreen(mode: String, onMode: (String) -> Unit, onSettings: () -> Unit, onPlay: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Box(Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                Text("◖  DELCLICK", color = PurpleLight, fontSize = 25.sp, fontWeight = FontWeight.Light, letterSpacing = 5.sp)
            }
        }
        item {
            CardBox {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, null, tint = Green, modifier = Modifier.size(30.dp))
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text("Tudo pronto", fontWeight = FontWeight.SemiBold, fontSize = 19.sp)
                        Text("Shizuku · Janelas · Roblox", color = Muted)
                    }
                    Spacer(Modifier.weight(1f))
                    Text("●", color = Green)
                }
            }
        }
        item {
            CardBox {
                Text("Como você quer jogar?", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ModeCard("Mouse e teclado", "Cursor e câmera como no PC.", mode == "Mouse e teclado", Modifier.weight(1f)) { onMode("Mouse e teclado") }
                    ModeCard("Controle", "Teclado e mouse como controle.", mode == "Controle", Modifier.weight(1f)) { onMode("Controle") }
                }
                Spacer(Modifier.height(12.dp))
                Text("Em Ajustes ficam Sensibilidade, Shift Lock e Cursor.", color = Muted)
                Spacer(Modifier.height(16.dp))
                PrimaryButton("▷  Jogar", onPlay)
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = onSettings, modifier = Modifier.fillMaxWidth()) { Text("Configurações") }
            }
        }
        item { Text("DelClick é um projeto independente em desenvolvimento.", color = Muted, fontSize = 12.sp) }
    }
}

@Composable
fun SettingsScreen(sens: Float, setSens: (Float) -> Unit, shift: Boolean, setShift: (Boolean) -> Unit,
                   camera: Boolean, setCamera: (Boolean) -> Unit, cursor: Boolean, setCursor: (Boolean) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            CardBox {
                Text("Sensibilidade", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Text("Câmera: %.2fx".format(sens), color = Muted)
                Slider(value = sens, onValueChange = setSens, valueRange = .25f..3f)
                Text("Cursor e câmera podem exigir calibração no jogo.", color = Muted)
            }
        }
        item {
            CardBox {
                Text("Shift Lock", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                SettingSwitch("Nosso Shift Lock", "Atalho para prender e liberar a câmera.", shift, setShift)
                Divider(color = Panel2)
                SettingSwitch("Camera Toggle", "Alternar o modo de câmera.", camera, setCamera)
            }
        }
        item {
            CardBox {
                Text("Cursor e ícones", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                SettingSwitch("Mostrar sempre", "Exibir o cursor personalizado no painel.", cursor, setCursor)
            }
        }
    }
}

@Composable
fun MacroScreen(count: Int, setCount: (Int) -> Unit) {
    var selected by remember { mutableIntStateOf(1) }
    var mode by remember { mutableStateOf("Segurar") }
    var delay by remember { mutableIntStateOf(60) }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            CardBox {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Macros", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    Text("GIRO OFF", color = Muted)
                }
                Text("Macro $selected", fontWeight = FontWeight.SemiBold)
                Text("Gravar: F6                 Tocar: F7", color = Muted)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Uma vez", "Segurar", "Liga/desliga", "N vezes").forEach {
                        FilterChip(selected = mode == it, onClick = { mode = it }, label = { Text(it, fontSize = 11.sp) })
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Respiro")
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { delay = (delay - 10).coerceAtLeast(10) }) { Text("−") }
                    Text("$delay ms")
                    TextButton(onClick = { delay = (delay + 10).coerceAtMost(1000) }) { Text("+") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { selected = (selected - 1).coerceAtLeast(1) }) { Text("Anterior") }
                    OutlinedButton(onClick = { selected = (selected + 1).coerceAtMost(count) }) { Text("Próxima") }
                }
                PrimaryButton("+ Nova macro") { setCount((count + 1).coerceAtMost(10)); selected = (count + 1).coerceAtMost(10) }
                Text("Protótipo: gravação e reprodução real ainda precisam ser conectadas ao serviço de entrada.", color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun AutoClickScreen(enabled: Boolean, setEnabled: (Boolean) -> Unit, rate: Float, setRate: (Float) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
        item {
            CardBox {
                Text("Autoclick", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                SettingSwitch("Autoclick", "Ativar ou desativar o recurso.", enabled, setEnabled)
                Text("Cliques por segundo: ${rate.toInt()}", color = Muted)
                Slider(value = rate, onValueChange = setRate, valueRange = 1f..20f, steps = 18)
                Text("Botão: esquerdo · direito · tecla", color = Muted)
                Text("Modo: segurar · liga/desliga", color = Muted)
                Text("A execução real será implementada após a integração segura com o serviço de entrada.", color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun KeyboardScreen() {
    val rows = listOf(listOf("1","2","3","4","5"), listOf("TAB","Q","W","E","R","T"), listOf("CAPS","A","S","D","F","G"), listOf("SHIFT","Z","X","C","V"), listOf("CTRL","ALT","ESPAÇO"))
    LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
        item {
            CardBox {
                Text("Teclado na tela", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text("Prévia do mapeamento de teclas", color = Muted)
                rows.forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                        row.forEach { key ->
                            Surface(color = Panel2, shape = RoundedCornerShape(9.dp), modifier = Modifier.padding(3.dp).weight(1f)) {
                                Text(key, Modifier.padding(vertical = 14.dp), color = PurpleLight, textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontSize = 12.sp)
                            }
                        }
                    }
                }
                Text("A prévia visual está pronta. Envio de teclas ao jogo ainda não está conectado.", color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun GamePanel(auto: Boolean, setAuto: (Boolean) -> Unit, rate: Float, setRate: (Float) -> Unit,
              shift: Boolean, setShift: (Boolean) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            CardBox {
                Text("Painel flutuante", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text("Sensibilidade", color = Muted)
                Text("Câmera: 1.00x")
                Text("Macros")
                PrimaryButton("Abrir macros") { }
                SettingSwitch("Autoclick", "Ativar autoclick", auto, setAuto)
                Text("Velocidade: ${rate.toInt()} por segundo")
                Slider(value = rate, onValueChange = setRate, valueRange = 1f..20f)
                SettingSwitch("Shift Lock", "Atalho de câmera", shift, setShift)
                PrimaryButton("Fechar painel") { }
            }
        }
    }
}

@Composable
fun DrawerItem(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(color = if (selected) Panel2 else Color.Transparent, shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { onClick() }) {
        Text(label, Modifier.padding(15.dp), color = if (selected) PurpleLight else Color.White, fontSize = 16.sp)
    }
}

@Composable
fun CardBox(content: @Composable ColumnScope.() -> Unit) {
    Surface(color = Panel, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}

@Composable
fun ModeCard(title: String, subtitle: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Surface(color = if (selected) Color(0xFF2B2047) else Bg,
        shape = RoundedCornerShape(18.dp), border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) Purple else Panel2),
        modifier = modifier.clickable { onClick() }) {
        Column(Modifier.padding(14.dp)) {
            Icon(if (title.startsWith("Mouse")) Icons.Default.Mouse else Icons.Default.SportsEsports, null, tint = PurpleLight)
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun PrimaryButton(label: String, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.fillMaxWidth().height(54.dp),
        shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
        Text(label, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun SettingSwitch(title: String, description: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium)
            Text(description, color = Muted, fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onChecked, colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Purple))
    }
}
