# DelClick — Android Studio starter

Projeto inicial em Kotlin + Jetpack Compose, com identidade visual inspirada nas referências fornecidas.

## Abrir
1. Extraia `DelClick-AndroidStudio.zip`.
2. Abra a pasta `DelClick` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Execute no emulador ou em um aparelho Android.

## Estado desta versão
Esta é uma versão inicial de interface (alpha). Navegação, seleção de modo, sliders e alternâncias da interface funcionam localmente.
Ainda NÃO implementa injeção real de mouse/teclado, overlay de jogo, captura UHID, integração Shizuku, gravação/reprodução real de macros nem autoclick no Roblox. Essas partes exigem implementação e testes específicos em aparelho físico e permissões explícitas.

## Requisitos
- Android Studio recente
- JDK 17
- Android SDK 35
- Gradle wrapper gerado pelo Android Studio na primeira abertura, se necessário

Package: `com.delclick.app`
Version: `1.0-alpha`
